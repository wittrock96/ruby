FactoryBot.define do
  factory :message do
    message "MyString"
    user nil
  end
end
