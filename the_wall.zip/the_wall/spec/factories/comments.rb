FactoryBot.define do
  factory :comment do
    content "MyString"
    post nil
  end
end
