FactoryBot.define do
  factory :secret do
    content "MyText"
    user nil
  end
end
