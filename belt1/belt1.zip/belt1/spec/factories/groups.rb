FactoryBot.define do
  factory :group do
    name "MyString"
    description "MyString"
    user nil
  end
end
