require 'rails_helper'

RSpec.describe MembersController, type: :controller do

end
