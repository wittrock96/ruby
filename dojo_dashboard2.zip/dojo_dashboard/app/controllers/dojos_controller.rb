class DojosController < ApplicationController
  def index
  	@dojos = Dojo.all
  end
  def new
  	@dojo = Dojo.new
  end
  def create
  	@new = Dojo.create(dojo_params)
  	redirect_to '/index'
  	
  end
  private
 	def dojo_params
  		params.require(:dojo).permit(:branch, :street, :city, :state)
  		
  	end
end
