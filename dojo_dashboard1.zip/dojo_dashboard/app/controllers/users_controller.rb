class UsersController < ApplicationController
  def index
  	@dojos = Dojo.all
  end

end
