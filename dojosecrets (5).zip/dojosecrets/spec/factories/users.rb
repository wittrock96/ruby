FactoryBot.define do
  factory :user do
    name "cole"
    email "cole@wittrock.com"
    password "password"
    password_confirmation "password"
  end
end
