FactoryBot.define do
  factory :like do
    user nil
    secret nil
  end
end
