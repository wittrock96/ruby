FactoryBot.define do
  factory :secret do
    content ""
    user nil
  end
end
