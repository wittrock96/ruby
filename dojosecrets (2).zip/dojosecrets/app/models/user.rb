class User < ActiveRecord::Base
  has_secure_password
  EMAIL_REGEX = /\b[A-Z0-9._%a-z\-]+@(?:[A-Z0-9a-z\-]+\.)+[A-Za-z]{2,4}\z/
  before_save :downcase
  validates :name, :email, :password, presence: true
  validates :email, format: {with: EMAIL_REGEX}, uniqueness: true
  validates :password, confirmation: true
  private
  	def downcase
  		self.name.downcase!
  		self.email.downcase!
  		
  	end
end
