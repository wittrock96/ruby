class PostsController < ApplicationController
	layout 'three_column'
  def index
  	
  end
end
