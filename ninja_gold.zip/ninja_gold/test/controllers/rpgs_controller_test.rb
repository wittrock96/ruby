require 'test_helper'

class RpgsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
